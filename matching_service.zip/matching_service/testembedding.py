from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')

# Textes simples
text1 = "chat"
text2 = "chien"
text3 = "chatte"

# Génération des embeddings
embedding1 = model.encode(text1).tolist()
embedding2 = model.encode(text2).tolist()
embedding3 = model.encode(text3).tolist()

print("Embedding 1:", embedding1[:5])  # Montre les 5 premiers éléments
print("Embedding 2:", embedding2[:5])
print("Embedding 3:", embedding3[:5])

import numpy as np

def cosine_similarity(embedding1, embedding2):
    # Produit scalaire
    dot_product = np.dot(embedding1, embedding2)
    # Normes des vecteurs
    norm1 = np.linalg.norm(embedding1)
    norm2 = np.linalg.norm(embedding2)
    # Calcul de la similarité cosinus
    return dot_product / (norm1 * norm2)

sim1=cosine_similarity(embedding1,embedding2)
print(sim1)
sim2=cosine_similarity(embedding2,embedding3)
print(sim2)
sim3=cosine_similarity(embedding1,embedding3)
print(sim3)



