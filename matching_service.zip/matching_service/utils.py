import requests
import numpy as np
from sentence_transformers import SentenceTransformer
from fastapi import HTTPException
import base64
import logging
import pdfplumber

logging.basicConfig(level=logging.INFO)

# Charger le modèle SentenceTransformer
model = SentenceTransformer("all-mpnet-base-v2")

# Fonction de décodage pour les données reçues
def decode_text(text: str) -> str:
    """
    Décoder un texte encodé en Base64 ou UTF-8 pour assurer une compatibilité.
    """
    try:
        return text.encode("utf-8").decode("utf-8")
    except UnicodeDecodeError:
        try:
            return base64.b64decode(text).decode("utf-8")
        except Exception as e:
            logging.error(f"Failed to decode text: {e}")
            raise ValueError("Invalid text encoding format.")

# Fonction pour encoder en Base64 si nécessaire
def encode_text(text: str) -> str:
    """
    Encoder un texte en Base64
    """
    return base64.b64encode(text.encode("utf-8")).decode("utf-8")

# Extraire et structurer un CV à partir d'un fichier PDF
def extract_and_structure_cv(file_path):
    """
    Extrait et structure un CV depuis un fichier pdf
    """
    with pdfplumber.open(file_path) as pdf:
        text = "\n".join(page.extract_text() for page in pdf.pages)

    structured_cv = {
        "contact": {},
        "summary": "",
        "education": [],
        "experience": [],
        "skills": []
    }

    # Détecter et structurer les sections
    lines = text.split("\n")
    current_section = None
    for line in lines:
        line = line.strip()
        if "Éducation" in line:
            current_section = "education"
        elif "Expérience" in line:
            current_section = "experience"
        elif "Compétences" in line:
            current_section = "skills"
        elif "Contact" in line:
            current_section = "contact"
        elif current_section == "education":
            structured_cv["education"].append(line)
        elif current_section == "experience":
            structured_cv["experience"].append(line)
        elif current_section == "skills":
            structured_cv["skills"].append(line)
        elif current_section == "contact":
            structured_cv["contact"] = line

    logging.info(f"Extracted structured CV: {structured_cv}")
    return structured_cv

# Générer des embeddings localement avec découpage
def generate_embedding_locally_with_split(text: str, max_length: int = 512) -> list:
    sentences = text.split(". ")
    embeddings = []
    current_chunk = ""
    for sentence in sentences:
        if len(current_chunk) + len(sentence) <= max_length:
            current_chunk += sentence + ". "
        else:
            embeddings.append(model.encode(current_chunk).tolist())
            current_chunk = sentence + ". "
    if current_chunk:
        embeddings.append(model.encode(current_chunk).tolist())
    logging.info(f"Generated {len(embeddings)} embeddings for split text.")
    return np.mean(embeddings, axis=0).tolist()

# Générer des embeddings localement
def generate_embedding_locally(text: str) -> list:
    text = decode_text(text)
    if not text.strip():
        logging.error("Input text is empty or invalid for embedding generation.")
        raise ValueError("Input text is empty or invalid for embedding generation.")
    logging.info(f"Generating embedding for text: {text[:50]}...")
    return model.encode(text).tolist()

# Récupérer les données d'un CV depuis le service CV
def fetch_cv_data(cv_id: int, token: str) -> str:
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(f"http://127.0.0.1:8001/cv/{cv_id}", headers=headers)
        response.raise_for_status()
        cv_text = response.json().get("text", "")
        decoded_text = decode_text(cv_text)
        logging.info(f"Fetched CV text: {decoded_text[:50]}...")
        return decoded_text
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching CV data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch CV data.")
    except ValueError as e:
        logging.error(f"Decoding error for CV data: {e}")
        raise HTTPException(status_code=500, detail="Failed to decode CV data.")

# Récupérer les données d'un job depuis le service Job
def fetch_job_data(job_id: int, token: str) -> str:
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(f"http://127.0.0.1:8002/job/{job_id}", headers=headers)
        response.raise_for_status()
        job_text = response.json().get("text", "")
        decoded_text = decode_text(job_text)
        logging.info(f"Fetched Job text: {decoded_text[:50]}...")
        return decoded_text
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching Job data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch Job data.")
    except ValueError as e:
        logging.error(f"Decoding error for Job data: {e}")
        raise HTTPException(status_code=500, detail="Failed to decode Job data.")

# Calculer la similarité cosinus entre deux embeddings
def calculate_similarity(embedding1: list, embedding2: list, threshold: float = 0.3) -> float:
    vec1 = np.array(embedding1)
    vec2 = np.array(embedding2)

    logging.info(f"Embedding 1 sample: {vec1[:5]}")
    logging.info(f"Embedding 2 sample: {vec2[:5]}")

    dot_product = np.dot(vec1, vec2)
    magnitude1 = np.linalg.norm(vec1)
    magnitude2 = np.linalg.norm(vec2)

    if magnitude1 == 0 or magnitude2 == 0:
        logging.warning("One of the embeddings is zero, similarity set to 0.")
        return 0.0

    similarity = dot_product / (magnitude1 * magnitude2)
    if similarity < threshold:
        logging.info(f"Similarity below threshold ({similarity} < {threshold}).")
        return 0.0
    logging.info(f"Cosine similarity: {similarity}")
    return float(similarity)

# Récupérer les données de tous les jobs disponibles
def fetch_all_jobs(token: str) -> list:
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(f"http://127.0.0.1:8002/jobs", headers=headers)
        response.raise_for_status()
        jobs = response.json()
        logging.info(f"Fetched {len(jobs)} jobs from the database.")
        return [
            decode_text(f"{job['description']} {job['skills']}") 
            for job in jobs
        ]
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching jobs data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch job data.")

def fetch_all_cvs(token: str) -> list:
    headers = {"Authorization": f"Bearer {token}"}
    try:
        # Appelle la route /cvs pour récupérer tous les CVs
        response = requests.get("http://127.0.0.1:8001/cvs", headers=headers)
        response.raise_for_status()
        cvs = response.json()  # Charger les CVs en JSON
        logging.info(f"Fetched {len(cvs)} CVs from the database.")
        return cvs
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching CVs data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch CVs.")
