from fastapi import APIRouter, HTTPException, Depends, Header, UploadFile, File
from sqlalchemy.orm import Session
from schemas import  MatchResultSchema, MatchResultsResponse
from database import get_db
from utils import generate_embedding_locally, fetch_all_cvs, fetch_job_data, calculate_similarity, decode_text,generate_embedding_locally_with_split,fetch_all_jobs
from models import MatchResult
import logging
import requests


logging.basicConfig(level=logging.INFO)

router = APIRouter()


@router.post("/cv-to-job", response_model=MatchResultsResponse)
async def match_cv_to_jobs_with_file(
    file: UploadFile = File(...),
    job_ids: list[int] = [],
    db: Session = Depends(get_db),
    authorization: str = Header(...),
):
    logging.info("Request received with file: %s", file.filename)

    # Vérifier le format du fichier
    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    # Lire le contenu du fichier
    try:
        file_content = await file.read()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}")

    # Extraire le texte du fichier PDF
    try:
        from PyPDF2 import PdfReader
        reader = PdfReader(file.file)
        cv_text = "".join(page.extract_text() for page in reader.pages)
        cv_text = decode_text(cv_text)  # Décoder le texte extrait
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error extracting text from PDF: {str(e)}")

    # Générer les embeddings pour le texte du CV
    cv_embedding = generate_embedding_locally_with_split(cv_text)

    results = []

    # ici si aucune `job_id` n'est fournie, récupérer toutes les jobs disponibles
    if not job_ids:
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Invalid token format")
        token = authorization.split(" ")[1]
        job_texts = fetch_all_jobs(token)  # Appelle la route pour récupérer tous les jobs
    else:
        # Simuler des textes pour les `job_ids` fournis (à remplacer par une logique réelle)
        job_texts = [f"Job description for job ID {job_id}" for job_id in job_ids]

    # Comparer le CV avec chaque description de job
    for idx, job_text in enumerate(job_texts):
        try:
            job_text = decode_text(job_text)  # Décoder les données des jobs
            job_embedding = generate_embedding_locally_with_split(job_text)
            similarity_score = calculate_similarity(cv_embedding, job_embedding)

            # Log la similarité pour chaque job
            logging.info(f"Similarity between uploaded CV and Job {idx + 1}: {similarity_score}")

            # Sauvegarder le résultat dans la base de données
            match_result = MatchResult(
                cv_id=None,  # jai pas mis did pour le fichier uploadé
                job_id=job_ids[idx] if job_ids else idx + 1,
                similarity_score=similarity_score,
            )
            db.add(match_result)
            db.commit()
            db.refresh(match_result)

            results.append(
                MatchResultSchema(
                    id=match_result.id,
                    cv_id=None,
                    job_id=job_ids[idx] if job_ids else idx + 1,
                    similarity_score=similarity_score,
                )
            )
        except Exception as e:
            logging.error(f"Error processing job {idx + 1}: {e}")
            continue  # Passer au job suivant en cas d'erreur

    # Retourner les résultats triés par similarité décroissante
    return MatchResultsResponse(
        results=sorted(results, key=lambda x: x.similarity_score, reverse=True)
    )


@router.post("/job-to-cv", response_model=MatchResultsResponse)
async def match_job_to_all_cvs(
    job_id: int,
    authorization: str = Header(...),
):
   
    logging.info(f"Matching job ID {job_id} to all available CVs")

    # Vérification de l'autorisation
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]

    # Récupération des données de la job offer via API
    try:
        job_text = fetch_job_data(job_id, token)  # Appelle le service pour récupérer la job
        logging.info(f"Job text retrieved for job ID {job_id}: {job_text[:50]}...")
    except Exception as e:
        logging.error(f"Failed to fetch job data for job ID {job_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch job data.")

    # Générer l'embedding pour la job offer
    try:
        job_embedding = generate_embedding_locally(job_text)
        logging.info(f"Generated embedding for job ID {job_id}")
    except Exception as e:
        logging.error(f"Failed to generate embedding for job ID {job_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate job embedding.")

    results = []

    # Récupération de tous les CVs via API
    try:
        cvs = fetch_all_cvs(token)  # Appelle le service pour récupérer tous les CVs
        logging.info(f"Retrieved {len(cvs)} CVs from the CV service.")
    except Exception as e:
        logging.error(f"Failed to fetch CVs: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch CVs.")

    # Calculer la similarité entre la job offer et chaque CV
    for cv in cvs:
        try:
            cv_id = cv.get("id")  # ID du CV
            cv_text = cv.get("text", "")  # Texte du CV directement depuis le service
            if not cv_text.strip():
                logging.warning(f"Empty or invalid CV text for CV ID {cv_id}")
                continue

            cv_embedding = generate_embedding_locally(cv_text)  # Générer l'embedding pour le CV
            similarity_score = calculate_similarity(job_embedding, cv_embedding)  # Calculer la similarité

            # Ajouter le résultat seulement si la similarité dépasse le seuil
            if similarity_score >= 0.3:
                results.append(
                    MatchResultSchema(
                        id=cv_id,  # Utilise l'ID du CV comme référence
                        cv_id=cv_id,
                        job_id=job_id,
                        similarity_score=similarity_score,
                    )
                )
                logging.info(f"Match calculated for CV ID {cv_id}: Similarity = {similarity_score}")
        except Exception as e:
            logging.error(f"Error processing CV ID {cv.get('id')}: {e}")
            continue  # Passer au CV suivant en cas d'erreur

    # Trier les résultats par score de similarité décroissant
    sorted_results = sorted(results, key=lambda x: x.similarity_score, reverse=True)

    logging.info(f"Matching completed for job ID {job_id}. Total matches: {len(sorted_results)}")
    return MatchResultsResponse(results=sorted_results)

