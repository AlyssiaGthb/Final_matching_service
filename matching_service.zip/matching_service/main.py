from fastapi import FastAPI
from routes import router 
from fastapi.middleware.cors import CORSMiddleware
'''import openai'''
import os
from dotenv import load_dotenv

# Charger la configuration (clé API OpenAI)
load_dotenv()
'''openai.api_key = os.getenv("OPENAI_API_KEY")
import openai
import os
from dotenv import load_dotenv

# Charger la clé depuis le fichier .env
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Tester l'accès à l'API
try:
    response = openai.Model.list()  # Nouvelle méthode supportée
    print("API Key is working. Models available:", [model["id"] for model in response["data"]])
except Exception as e:
    print("Error with API Key:", e)


if not openai.api_key:
    raise ValueError("OPENAI_API_KEY is not set in the .env file.")'''

# Initialisation de l'application FastAPI
app = FastAPI(
    title="Matching Service",
    description="Service de matching pour associer CVs et Jobs",
    version="1.0.0",
)
# Configuration CORS
origins = [
    "http://localhost:3000",  # React en local
    "http://localhost:5173",  # Vite.js en local
    "http://127.0.0.1:3000",  # React en local sur IP
    "http://127.0.0.1:5173",  # Vite.js en local sur IP
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Autorise toutes les méthodes HTTP
    allow_headers=["*"],  # Autorise tous les headers
)




# Inclure les routes
app.include_router(router)
