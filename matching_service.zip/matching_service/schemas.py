from pydantic import BaseModel
from typing import List
from typing import Optional

class MatchCVToJobRequest(BaseModel):
    cv_id: Optional[int] = None
    cv_text: Optional[str] = None  
    job_ids: List[int]

class MatchJobToCVRequest(BaseModel):
    job_id: int
    cv_ids: List[int]

class MatchResultSchema(BaseModel):
    id: int
    cv_id: Optional[int] = None
    job_id: int
    similarity_score: float

class MatchResultsResponse(BaseModel):
    results: List[MatchResultSchema]


