from sqlalchemy import Column, Integer, Float
from database import Base

class MatchResult(Base):
    __tablename__ = "match_results"

    id = Column(Integer, primary_key=True, index=True)
    cv_id = Column(Integer, nullable=True)
    job_id = Column(Integer, nullable=False)
    similarity_score = Column(Float, nullable=False)
